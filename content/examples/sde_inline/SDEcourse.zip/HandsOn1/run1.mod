$PROBLEM Sim

$INPUT ID TIME DV AMT CMT EVID

$DATA sim.dta IGNORE=@

$SUBROUTINE ADVAN6 TOL 6 DP

$MODEL COMP = (CENT)

$PK
    
  CL  = THETA(1)*EXP(ETA(1))
  V1  = THETA(2)*EXP(ETA(2))
  SGW1 = THETA(3)
  IF(NEWIND.NE.2) OT = 0

$DES
  DADT(1) = -CL/V1*A(1)

$ERROR
  IF(TIME.EQ.0.AND.ICALL.EQ.4) THEN
    AHT1 = 0                        ; Initiation of absorption compartment
    TID  = 1000                     ; Skip the system noise at t=0 
  ENDIF

  IF(AMT.GT.0.AND.ICALL.EQ.4) THEN
    AHT1 = AHT1+AMT                    ; Dosing
  ENDIF
  
  IF(TIME.GT.0.AND.ICALL.EQ.4) THEN ; Calculate DELTAT and DELT and set TID=0
    DELTAT = TIME-OT
    NSTEP=100
    DELT = DELTAT/NSTEP
    TID = 0
  ENDIF
IF(ICALL.EQ.4) THEN                 ; Euler approximation
   DOWHILE (TID.LT.NSTEP)
       CALL SIMEPS(EPS)
       DW1  = SQRT(DELT)*EPS(1)
       AHT1 = AHT1 -(CL/V1*AHT1)*DELT + SGW1*DW1
       TID  = TID + 1
   ENDDO

   W      = THETA(4)
   Y      = AHT1/V1*(1 + W*EPS(2))
   ABSC=AHT1
   OT = TIME
   RETURN
 ENDIF
  IPRED = A(1)/V1
  IRES  = DV-IPRED
  W     = THETA(4)
  Y     = IPRED*(1+W*EPS(2))

$THETA (0,5.5)         ; 1  CL
$THETA (0,38)          ; 2  V1
$THETA (0,40)          ; 3  SIGW1
$THETA (0,0.01)        ; 4  PROP SIGMA

$OMEGA 0.04            ; 1  CL
$OMEGA 0.04            ; 2  V1

$SIGMA 1 FIX
$SIGMA 1 FIX

$SIM(5435654 NORMAL NEW) 

$TABLE ID TIME EVID MDV IPRED ONEHEADER NOPRINT FILE=mod1.tab

