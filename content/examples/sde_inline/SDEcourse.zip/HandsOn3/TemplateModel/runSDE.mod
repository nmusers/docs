$PROBLEM PKSDE

$INPUT ID TIME DV EVID AMT CMT MDV SDE NTIM
$DATA  NMData.dataSDE       
   IGNORE=@

$SUBROUTINE ADVAN6 TOL 3 DP

$MODEL COMP = (CENTRAL)
       COMP = (P1) 

$THETA (0, 5.5  )          ; 1  CL - Clearance
$THETA (0, 38 )            ; 2  VD - Volume of Distribution

$THETA (0 , 0.1 )          ; 3  W    - Observation error std.
$THETA (0 , 1 )            ; 4  SGW1 - Noise Scale
 
$OMEGA 0 FIX               ; 1  CL
$OMEGA 0 FIX               ; 2  V

$SIGMA 1 FIX


$PK
TCL = THETA(1)
CL  = TCL*EXP(ETA(1))
TVD = THETA(2) 
VD  = TVD*EXP(ETA(2))

SGW1 = THETA(4)

  
IF(NEWIND.NE.2) THEN
  AHT1 = 0
  PHT1 = 0
ENDIF

IF(EVID.NE.3) THEN
  A1 = A(1)
  A2 = A(2)
ELSE
  A1 = A1
  A2 = A2
ENDIF

IF(EVID.EQ.0) OBS = DV

IF(EVID.GT.2.AND.SDE.EQ.2) THEN
  ;; INSERT R EQUATION USING AX's
  RVAR = 
 
  ;; INSERT K EQUATIONS USING AX's
  K1   = 

  ;; INSERT X_i(j|j) EQUATIONS USING AX's
  AHT1 = 

  ;; INSERT P_i(j|j) EQUATIONS USING AX's
  PHT1 = 
ENDIF


IF(A_0FLG.EQ.1) THEN
  A_0(1) = AHT1
  A_0(2) = PHT1
ENDIF


$DES
DADT(1) = -(CL/VD)*A(1)

;; INSERT P EQUATION USING A(X)
DADT(2) = 


$ERROR

  ;; INSERT R EQUATION USING A(X)
  VAR = 

  IPRED = LOG(A(1)/VD)
  W     = SQRT(VAR)
  IRES  = DV-IPRED
  IWRES = IRES/W
  Y     = IPRED+W*EPS(1) 

$EST MAXEVAL=9999 METH=1 INTER PRINT=1 SIGDIGITS=3 NOABORT

$TABLE ID TIME DV SDE EVID AMT CMT IPRED IRES
       ONEHEADER NOPRINT FILE=tabSDE