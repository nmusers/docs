$PROBLEM Sim

$INPUT ID TIME DV AMT CMT EVID

$DATA sim.dta IGNORE=@

$SUBROUTINE ADVAN6 TOL 6 DP

$MODEL COMP = (ABS)
$MODEL COMP = (CENT)

$PK
  KA=0.01 
  CL  = THETA(1)*EXP(ETA(1))
  V1  = THETA(2)*EXP(ETA(2))
  SGW1 = THETA(3)
  SGW2 = THETA(4)
  IF(NEWIND.NE.2) OT = 0

$DES
  DADT(1) = -KA*A(1)
  DADT(2) = KA*A(1)-CL/V1*A(2)

$ERROR
  IF(TIME.EQ.0.AND.ICALL.EQ.4) THEN
    AHT1 = 0                        ; Initiation of absorption compartment
    AHT2 = 0
    TID  = 1000                     ; Skip the system noise at t=0 
  ENDIF

  IF(AMT.GT.0.AND.ICALL.EQ.4) THEN
    AHT1 = AHT1+AMT                    ; Dosing
  ENDIF
  
  IF(TIME.GT.0.AND.ICALL.EQ.4) THEN ; Calculate DELTAT and DELT and set TID=0
    DELTAT = TIME-OT
    NSTEP=100
    DELT = DELTAT/NSTEP
    TID = 0
  ENDIF
IF(ICALL.EQ.4) THEN                 ; Euler approximation
   DOWHILE (TID.LT.NSTEP)
       CALL SIMEPS(EPS)
       DW1  = SQRT(DELT)*EPS(1)
       DW2  = SQRT(DELT)*EPS(2)
       AHT1 = AHT1 -(KA*AHT1)*DELT + SGW1*DW1
       AHT2 = AHT2 +(KA*AHT1-CL/V1*AHT2)*DELT + SGW2*DW2
       TID  = TID + 1
   ENDDO

   W      = THETA(5)
   Y      = AHT2/V1*(1 + W*EPS(2))
   ABSC=AHT1
   OT = TIME
   RETURN
 ENDIF
  IPRED = A(2)/V1
  IRES  = DV-IPRED
  W     = THETA(5)
  Y     = IPRED*(1+W*EPS(3))

$THETA (0,5.5)         ; 1  CL
$THETA (0,38)          ; 2  V1
$THETA (0,0,40) FIX         ; 3  SIGW1
$THETA (0,0,60) FIX         ; 4  SIGW2
$THETA (0,0.01)        ; 5  PROP SIGMA

$OMEGA 0.04            ; 1  CL
$OMEGA 0.04            ; 2  V1

$SIGMA 1 FIX
$SIGMA 1 FIX
$SIGMA 1 FIX

$SIM(5435654 NORMAL NEW) 

$TABLE ID TIME EVID MDV IPRED ONEHEADER NOPRINT FILE=mod3.tab

